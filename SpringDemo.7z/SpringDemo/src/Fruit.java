
public class Fruit {

	
	private String name;
	
	private String price;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	
	public void fruit_inf0()
	{
		System.out.println("fuit name:"+name);
		System.out.println("fruit price"+price);
	}
}
