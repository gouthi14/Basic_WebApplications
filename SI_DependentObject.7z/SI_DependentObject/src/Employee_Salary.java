
public class Employee_Salary {
private int rate;
private String palce;
 private Employee employee;
 
 
public Employee getEmployee() {
	return employee;
}
public void setEmployee(Employee employee) {
	this.employee = employee;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public String getPalce() {
	return palce;
}
public void setPalce(String palce) {
	this.palce = palce;
}


void fruit_info()
{
	System.out.println(rate);
	System.out.println(palce);
}
}
